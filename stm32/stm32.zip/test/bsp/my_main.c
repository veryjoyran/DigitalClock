#include "my_main.h"

uint8_t led_sta=0x00;
char text[30];
char uart_tx[50];
char uart_rx[50];
extern struct Bkeys bkey[];
extern struct MyTime currentTime,alarmTime1,alarmTime2,second_chronograph;
extern struct Date currentDate;
char password[3]={'1','2','3'};
uint8_t eep_num;


uint32_t time500ms;

typedef enum SettingMode {
    SET_NONE,
    SET_HOUR,
    SET_MINUTE,
    SET_SECOND,
    SET_YEAR,
    SET_MONTH,
    SET_DAY,
    SET_ALARM1_HOUR,
    SET_ALARM1_MINUTE,
    SET_ALARM1_SECOND,
	SET_ALARM2_HOUR,
    SET_ALARM2_MINUTE,
    SET_ALARM2_SECOND
}SettingMode;

// 当前的设置模式
SettingMode currentSettingMode = SET_NONE;



void LED_Disp(uint8_t dsLED)
{
	HAL_GPIO_WritePin(GPIOC,GPIO_PIN_All,GPIO_PIN_SET);//所有LED熄灭
	HAL_GPIO_WritePin(GPIOC,dsLED<<8,GPIO_PIN_RESET);//左移8位，控制C8-15引脚，值为1的点亮
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);//开锁存器
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_RESET);
}

float adc_read_os(ADC_HandleTypeDef *hadc)
{
	uint16_t adc_val;
	float adc_f;
	HAL_ADC_Start(hadc);
	adc_val=HAL_ADC_GetValue(hadc);
	adc_f=adc_val*3.3f/65536.0f;
	return adc_f;
	
}
float adc_read(ADC_HandleTypeDef *hadc)
{
	uint16_t adc_val;
	float adc_f;
	HAL_ADC_Start(hadc);
	adc_val=HAL_ADC_GetValue(hadc);
	adc_f=adc_val*3.3f/4096.0f;
	return adc_f;
	
}

void LED_Change(uint8_t num,uint8_t sta) //1~8
{
	uint8_t pos=0x01<<(num-1);
	led_sta=(led_sta&(~pos))|(pos*sta);
	LED_Disp(led_sta);
}

void disWeek(int y,int m, int d){           
    if(m == 1){
        m = 13;
    }
    if(m == 2){
        m = 14;
    } 
    int week = (d+2*m+3*(m+1)/5+y+y/4-y/100+y/400)%7+1; 
	char weekstr[30]; 
    switch(week){
		case 1: strcpy(weekstr, "     Monday            ");   break;
        case 2: strcpy(weekstr, "     Tuesday           ");   break;  
        case 3: strcpy(weekstr, "     Wednesday         ");   break;
        case 4: strcpy(weekstr, "     Thursday          ");   break;
        case 5: strcpy(weekstr, "     Friday            ");   break;
        case 6: strcpy(weekstr, "     Saturday          ");   break;
        case 7: strcpy(weekstr, "     Sunday            ");   break;
    }    
	LCD_DisplayStringLine(Line2,(uint8_t *)weekstr);
}

void disDate()
{
	sprintf(text,"      %d-%d-%d      ",currentDate.year,currentDate.month,currentDate.day);
	LCD_DisplayStringLine(Line3,(uint8_t *)text);
}
void disTime()
{
	sprintf(text,"       %d:%d:%d      ",currentTime.hour,currentTime.minute,currentTime.second);
	LCD_DisplayStringLine(Line4,(uint8_t *)text);
}
void disAlarmTime1()
{
	sprintf(text,"  Alarm1:  %d:%d:%d      ",alarmTime1.hour,alarmTime1.minute,alarmTime1.second);
	LCD_DisplayStringLine(Line5,(uint8_t *)text);
}

void disAlarmTime2()
{
	sprintf(text,"  Alarm2:  %d:%d:%d      ",alarmTime2.hour,alarmTime2.minute,alarmTime2.second);
	LCD_DisplayStringLine(Line6,(uint8_t *)text);
}

void disSecondChronograph()
{
	sprintf(text,"  Timer:  %d:%d:%d      ",second_chronograph.hour,second_chronograph.minute,second_chronograph.second);
	LCD_DisplayStringLine(Line7,(uint8_t *)text);
}

void disCurrentSettingMode() {
    strcpy(text, "CurrentMode:"); 
    switch (currentSettingMode) {
        case SET_NONE:
            strcat(text, "Display"); 
            break;
        case SET_HOUR:
            strcat(text, "Hour    "); 
            break;
        case SET_MINUTE:
            strcat(text, "Minute   "); 
            break;
        case SET_SECOND:
            strcat(text, "Second    "); 
            break;
        case SET_YEAR:
            strcat(text, "Year   "); 
            break;
        case SET_MONTH:
            strcat(text, "Month  "); 
            break;
        case SET_DAY:
            strcat(text, "Day   "); 
            break;
        case SET_ALARM1_HOUR:
            strcat(text, "A1-Hour   "); 
            break;
        case SET_ALARM1_MINUTE:
            strcat(text, "A1-Min   "); 
            break;
        case SET_ALARM1_SECOND:
            strcat(text, "A1-Sec   "); 
            break;
		case SET_ALARM2_HOUR:
            strcat(text, "A2-Hour   "); 
            break;
        case SET_ALARM2_MINUTE:
            strcat(text, "A2-Min   "); 
            break;
        case SET_ALARM2_SECOND:
            strcat(text, "A2-Sec   "); 
            break;
		
    }

    // 使用LCD显示函数显示字符串
    LCD_DisplayStringLine(Line9, (uint8_t *)text);
}



void Display()
{
	LCD_SetBackColor(Yellow);
	sprintf(text,"   Digital Clock    ");
	LCD_DisplayStringLine(Line0,(uint8_t *)text);
	
	LCD_SetBackColor(Blue);
	sprintf(text,"   LQR-20226494       ");
	LCD_DisplayStringLine(Line1,(uint8_t *)text);
	
	LCD_SetBackColor(Black);
	disWeek(currentDate.year,currentDate.month,currentDate.day);
	disDate();
	disTime();
	disAlarmTime1();
	disAlarmTime2();
	disSecondChronograph();
	disCurrentSettingMode();
	
	
}


void setup()
{
	HAL_TIM_Base_Start_IT(&htim6);
	HAL_TIM_Base_Start_IT(&htim7);
	HAL_TIM_PWM_Start(&htim2,TIM_CHANNEL_2); 
	//TIM15_CH1输入演示
	HAL_TIM_IC_Start(&htim15,TIM_CHANNEL_1);
	HAL_TIM_IC_Start(&htim15,TIM_CHANNEL_2);
	
	HAL_UARTEx_ReceiveToIdle_IT(&huart1,(uint8_t *)uart_rx,50);
	HAL_ADCEx_Calibration_Start(&hadc2,ADC_SINGLE_ENDED);
	
	LED_Disp(0x00);
	//HAL_GPIO_WritePin(GPIOD,GPIO_PIN_2,GPIO_PIN_SET);//解锁锁存器
	//HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8,GPIO_PIN_RESET);
	
	clock_init();
	LCD_Init();
	LCD_Clear(Black);
	LCD_SetBackColor(Black);
	LCD_SetTextColor(White);
	I2CInit();
	eep_num=eeprom_read(8);

	time500ms=uwTick;
}

void loop()
{
	static uint16_t temp;
	float frq1=0;
	float duty1=0;
	frq1=1000000.0f/(HAL_TIM_ReadCapturedValue(&htim15,TIM_CHANNEL_1)+1);
	duty1=((HAL_TIM_ReadCapturedValue(&htim15,TIM_CHANNEL_2)+1)*100.0f/(HAL_TIM_ReadCapturedValue(&htim15,TIM_CHANNEL_1)+1));
	float adc_data_PB15;
	
	Display();
	
//	sprintf(text,"   FQR:%.2fHz      ",frq1);
//	LCD_DisplayStringLine(Line1,(uint8_t *)text);
//	sprintf(text,"   DUTY:%.2f%%     ",duty1);
//	LCD_DisplayStringLine(Line2,(uint8_t *)text);
	
	//第五个LED常亮，第一个闪烁
	/*led_sta=(led_sta&0xfe)|0x01;
	LED_Disp(led_sta);
	HAL_Delay(500);
	led_sta=(led_sta&0xfe)|0x00;
	LED_Disp(led_sta);
	HAL_Delay(500);*/
	

	
	if(alarmTime1.hour==currentTime.hour&&alarmTime1.minute==currentTime.minute&&alarmTime1.second==currentTime.second)
	{
		LED_Change(2,1);
		LED_Change(4,1);
		LED_Change(6,1);
		LED_Change(8,1);
	}
	
	if(alarmTime2.hour==currentTime.hour&&alarmTime2.minute==currentTime.minute&&alarmTime2.second==currentTime.second)
	{
		LED_Change(1,1);
		LED_Change(3,1);
		LED_Change(5,1);
		LED_Change(7,1);
	}
	
	/*if(uwTick-time500ms>500)
	{
		static uint8_t LED_sta=0;
		LED_Change(2,LED_sta);
		LED_sta=!LED_sta;
		time500ms=uwTick;
	}*/
	
//	
//	adc_data_PB15=adc_read_os(&hadc2);
//	sprintf(text,"    PB15:%.4f    ",adc_data_PB15);
//	LCD_DisplayStringLine(Line5,(uint8_t *)text);	
	
	//sprintf(uart_tx,"PB15:%.4fV   \r\n ",adc_data_PB15);
	//HAL_UART_Transmit(&huart1,(uint8_t *)uart_tx,strlen(uart_tx),50);
	
//	sprintf(text,"    EEP:%d    ",eep_num);
//	LCD_DisplayStringLine(Line6,(uint8_t *)text);	
	
	if(bkey[1].short_flag==1)
	{
//		sprintf(text,"    KEY1_Down    ");
//		LCD_DisplayStringLine(Line8,(uint8_t *)text);
//		__HAL_TIM_SET_AUTORELOAD(&htim2,250-1);
//		__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,100);
		switch (currentSettingMode) {
        case SET_NONE:
            currentSettingMode = SET_HOUR; // 从不设置模式切换到设置小时
            break;
        case SET_HOUR:
            currentSettingMode = SET_MINUTE; // 从设置小时切换到设置分钟
            break;
        case SET_MINUTE:
            currentSettingMode = SET_SECOND; // 从设置分钟切换到设置秒
            break;
        case SET_SECOND:
            currentSettingMode = SET_YEAR; // 从设置秒切换到设置年份
            break;
        case SET_YEAR:
            currentSettingMode = SET_MONTH; // 从设置年份切换到设置月份
            break;
        case SET_MONTH:
            currentSettingMode = SET_DAY; // 从设置月份切换到设置日期
            break;
        case SET_DAY:
            currentSettingMode = SET_ALARM1_HOUR; // 从设置日期切换到设置闹钟小时
            break;
        case SET_ALARM1_HOUR:
            currentSettingMode = SET_ALARM1_MINUTE; // 从设置闹钟小时切换到设置闹钟分钟
            break;
        case SET_ALARM1_MINUTE:
            currentSettingMode = SET_ALARM1_SECOND; // 从设置闹钟分钟切换到设置闹钟秒
            break;
        case SET_ALARM1_SECOND:
            currentSettingMode = SET_ALARM2_HOUR; 
		case SET_ALARM2_HOUR:
            currentSettingMode = SET_ALARM2_MINUTE; // 从设置闹钟小时切换到设置闹钟分钟
            break;
        case SET_ALARM2_MINUTE:
            currentSettingMode = SET_ALARM2_SECOND; // 从设置闹钟分钟切换到设置闹钟秒
            break;
        case SET_ALARM2_SECOND:
            currentSettingMode = SET_NONE;
            break;
    }	
		bkey[1].short_flag=0;
	}
	if(bkey[1].long_flag==1)
	{
		if(currentSettingMode==SET_NONE)
		{
			currentSettingMode=SET_HOUR;
		}
		else if(currentSettingMode>=SET_HOUR&&currentSettingMode<=SET_SECOND)
		{
			currentSettingMode=SET_YEAR;
		}
		else if(currentSettingMode>=SET_YEAR&&currentSettingMode<=SET_DAY)
		{
			currentSettingMode=SET_ALARM1_HOUR;
		}
		else if(currentSettingMode>=SET_ALARM1_HOUR&&currentSettingMode<=SET_ALARM1_SECOND)
		{
			currentSettingMode=SET_ALARM2_HOUR;
		}
		else if(currentSettingMode>=SET_ALARM2_HOUR&&currentSettingMode<=SET_ALARM2_SECOND)
		{
			currentSettingMode=SET_NONE;
		}
		
	}
	
	
	if(bkey[2].short_flag==1)
	{
//		eep_num++;
//		eeprom_write(8,eep_num);
//		sprintf(text,"    KEY2_Down    ");
//		LCD_DisplayStringLine(Line8,(uint8_t *)text);
//		bkey[2].short_flag=0;
		if (currentSettingMode != SET_NONE) {
        switch (currentSettingMode) {
            case SET_HOUR:
                currentTime.hour = (currentTime.hour + 1) % 24;
                break;
            case SET_MINUTE:
                currentTime.minute = (currentTime.minute + 1) % 60;
                break;
            case SET_SECOND:
                currentTime.second = (currentTime.second + 1) % 60;
                break;
            case SET_YEAR:
                currentDate.year++;
                if (currentDate.year > 9999) 
					currentDate.year = 2000; // 设定一个合理的范围
                break;
            case SET_MONTH:
                currentDate.month = (currentDate.month % 12) + 1;
                break;
            case SET_DAY:
                if((currentDate.month==1)||(currentDate.month==3)||(currentDate.month==5)||(currentDate.month==7)||(currentDate.month==8)||(currentDate.month==10)||(currentDate.month==12))
                {
                  currentDate.day = (currentDate.day % 31) + 1;
                }
                else if((currentDate.month==4)||(currentDate.month==6)||(currentDate.month==9)||(currentDate.month==11))
                {
                  currentDate.day = (currentDate.day % 30) + 1;
                }
                else 
                {
                  if((currentDate.year%400==0)||((currentDate.year%100!=0)&&(currentDate.year%4==0)))  
                  {
                    currentDate.day = (currentDate.day % 29) + 1;
                  }
                  else
                  {
                    currentDate.day = (currentDate.day % 28) + 1;  
                  }
                }
                break;
             case SET_ALARM1_HOUR:
                alarmTime1.hour = (alarmTime1.hour + 1) % 24;
                break;
            case SET_ALARM1_MINUTE:
                alarmTime1.minute = (alarmTime1.minute + 1) % 60;
                break;
            case SET_ALARM1_SECOND:
                alarmTime1.second = (alarmTime1.second + 1) % 60;
                break;
			case SET_ALARM2_HOUR:
                alarmTime2.hour = (alarmTime2.hour + 1) % 24;
                break;
            case SET_ALARM2_MINUTE:
                alarmTime2.minute = (alarmTime2.minute + 1) % 60;
                break;
            case SET_ALARM2_SECOND:
                alarmTime2.second = (alarmTime2.second + 1) % 60;
                break;
        }
		
	}
		bkey[2].short_flag=0;
}
   	
	if(bkey[2].long_flag==1)
	{
		if (currentSettingMode != SET_NONE) {
        switch (currentSettingMode) {
            case SET_HOUR:
                currentTime.hour = (currentTime.hour + 1) % 24;
                break;
            case SET_MINUTE:
                currentTime.minute = (currentTime.minute + 1) % 60;
                break;
            case SET_SECOND:
                currentTime.second = (currentTime.second + 1) % 60;
                break;
            case SET_YEAR:
                currentDate.year++;
                if (currentDate.year > 9999) 
					currentDate.year = 2000; // 设定一个合理的范围
                break;
            case SET_MONTH:
                currentDate.month = (currentDate.month % 12) + 1;
                break;
            case SET_DAY:
                if((currentDate.month==1)||(currentDate.month==3)||(currentDate.month==5)||(currentDate.month==7)||(currentDate.month==8)||(currentDate.month==10)||(currentDate.month==12))
                {
                  currentDate.day = (currentDate.day % 31) + 1;
                }
                else if((currentDate.month==4)||(currentDate.month==6)||(currentDate.month==9)||(currentDate.month==11))
                {
                  currentDate.day = (currentDate.day % 30) + 1;
                }
                else 
                {
                  if((currentDate.year%400==0)||((currentDate.year%100!=0)&&(currentDate.year%4==0)))  
                  {
                    currentDate.day = (currentDate.day % 29) + 1;
                  }
                  else
                  {
                    currentDate.day = (currentDate.day % 28) + 1;  
                  }
                }
                break;
             case SET_ALARM1_HOUR:
                alarmTime1.hour = (alarmTime1.hour + 1) % 24;
                break;
            case SET_ALARM1_MINUTE:
                alarmTime1.minute = (alarmTime1.minute + 1) % 60;
                break;
            case SET_ALARM1_SECOND:
                alarmTime1.second = (alarmTime1.second + 1) % 60;
                break;
			case SET_ALARM2_HOUR:
                alarmTime2.hour = (alarmTime2.hour + 1) % 24;
                break;
            case SET_ALARM2_MINUTE:
                alarmTime2.minute = (alarmTime2.minute + 1) % 60;
                break;
            case SET_ALARM2_SECOND:
                alarmTime2.second = (alarmTime2.second + 1) % 60;
                break;
        }
		
	}
	}
	if(bkey[3].short_flag==1)
	{
		if (currentSettingMode != SET_NONE) {
		switch (currentSettingMode) {
      case SET_HOUR:
        currentTime.hour = (currentTime.hour + 23) % 24; // 循环减1
        break;
      case SET_MINUTE:
        currentTime.minute = (currentTime.minute + 59) % 60;
        break;
      case SET_SECOND:
        currentTime.second = (currentTime.second + 59) % 60;
        break;
      case SET_YEAR:
        currentDate.year--;
        if (currentDate.year < 2000) currentDate.year = 2024;
        break;
      case SET_MONTH:
        currentDate.month = (currentDate.month + 10) % 12 + 1;
        break;
      case SET_DAY:
        if((currentDate.month==1)||(currentDate.month==3)||(currentDate.month==5)||(currentDate.month==7)||(currentDate.month==8)||(currentDate.month==10)||(currentDate.month==12))
        {
             currentDate.day = (currentDate.day+29) % 31 + 1;
        }
        else if((currentDate.month==4)||(currentDate.month==6)||(currentDate.month==9)||(currentDate.month==11))
        {
             currentDate.day = (currentDate.day+28) % 30 + 1;
        }
        else 
        {
           if((currentDate.year%400==0)||((currentDate.year%100!=0)&&(currentDate.year%4==0)))  
           {
               currentDate.day = (currentDate.day+27) % 29 + 1;
           }
            else
            {
                currentDate.day = (currentDate.day+26) % 28 + 1;  
            }
         }
        break;
       case SET_ALARM1_HOUR:
           alarmTime1.hour = (alarmTime1.hour + 23) % 24;
             break;
       case SET_ALARM1_MINUTE:
          alarmTime1.minute = (alarmTime1.minute + 59) % 60;
            break;
       case SET_ALARM1_SECOND:
           alarmTime1.second = (alarmTime1.second + 59) % 60;
               break;
	   case SET_ALARM2_HOUR:
           alarmTime2.hour = (alarmTime2.hour + 23) % 24;
             break;
       case SET_ALARM2_MINUTE:
          alarmTime2.minute = (alarmTime2.minute + 59) % 60;
            break;
       case SET_ALARM2_SECOND:
           alarmTime2.second = (alarmTime2.second + 59) % 60;
               break;
    }
		
		bkey[3].short_flag=0;
	}
}
	
	if(bkey[3].long_flag==1)
	{
		if (currentSettingMode != SET_NONE) {
		switch (currentSettingMode) {
      case SET_HOUR:
        currentTime.hour = (currentTime.hour + 23) % 24; // 循环减1
        break;
      case SET_MINUTE:
        currentTime.minute = (currentTime.minute + 59) % 60;
        break;
      case SET_SECOND:
        currentTime.second = (currentTime.second + 59) % 60;
        break;
      case SET_YEAR:
        currentDate.year--;
        if (currentDate.year < 2000) currentDate.year = 2024;
        break;
      case SET_MONTH:
        currentDate.month = (currentDate.month + 10) % 12 + 1;
        break;
      case SET_DAY:
        if((currentDate.month==1)||(currentDate.month==3)||(currentDate.month==5)||(currentDate.month==7)||(currentDate.month==8)||(currentDate.month==10)||(currentDate.month==12))
        {
             currentDate.day = (currentDate.day+29) % 31 + 1;
        }
        else if((currentDate.month==4)||(currentDate.month==6)||(currentDate.month==9)||(currentDate.month==11))
        {
             currentDate.day = (currentDate.day+28) % 30 + 1;
        }
        else 
        {
           if((currentDate.year%400==0)||((currentDate.year%100!=0)&&(currentDate.year%4==0)))  
           {
               currentDate.day = (currentDate.day+27) % 29 + 1;
           }
            else
            {
                currentDate.day = (currentDate.day+26) % 28 + 1;  
            }
         }
        break;
       case SET_ALARM1_HOUR:
           alarmTime1.hour = (alarmTime1.hour + 23) % 24;
             break;
       case SET_ALARM1_MINUTE:
          alarmTime1.minute = (alarmTime1.minute + 59) % 60;
            break;
       case SET_ALARM1_SECOND:
           alarmTime1.second = (alarmTime1.second + 59) % 60;
               break;
	   case SET_ALARM2_HOUR:
           alarmTime2.hour = (alarmTime2.hour + 23) % 24;
             break;
       case SET_ALARM2_MINUTE:
          alarmTime2.minute = (alarmTime2.minute + 59) % 60;
            break;
       case SET_ALARM2_SECOND:
           alarmTime2.second = (alarmTime2.second + 59) % 60;
               break;
    }
	}
}
	/*if(bkey[1].long_flag==1)
	{
		sprintf(text,"    KEY1_long       ");
		LCD_DisplayStringLine(Line8,(uint8_t *)text);
		bkey[1].long_flag=0;
	}
	if(bkey[2].long_flag==1)
	{
		sprintf(text,"    KEY2_long      ");
		LCD_DisplayStringLine(Line8,(uint8_t *)text);
		bkey[2].long_flag=0;
	}*/
//	if(bkey[1].double_flag==1)
//	{
//		sprintf(text,"    KEY1_double       ");
//		LCD_DisplayStringLine(Line8,(uint8_t *)text);
//		bkey[1].double_flag=0;
//	}
//	if(bkey[2].double_flag==1)
//	{
//		sprintf(text,"    KEY2_double      ");
//		LCD_DisplayStringLine(Line8,(uint8_t *)text);
//		bkey[2].double_flag=0;
//	}
	/*sprintf(text,"    number:%d    ",14);
	LCD_DisplayStringLine(Line8,(uint8_t *)text);
	
	LCD_SetBackColor(Yellow);
	sprintf(text,"    T:%d                  ",30);
	LCD_DisplayStringLine(Line5,(uint8_t *)text);
	
	LCD_SetBackColor(Black);
	sprintf(text,"    X:A01    ");
	LCD_DisplayStringLine(Line6,(uint8_t *)text);*/
	
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance==TIM6)
		key_serv_long();
	if(htim->Instance==TIM7)
		clock_run();
	
}


void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    int hour, minute, second;
    // 尝试从接收的数据中解析时、分、秒
    if (sscanf(uart_rx, "%d:%d:%d", &hour, &minute, &second) == 3)
    {
        // 验证时间的有效性
        if (hour >= 0 && hour < 24 && minute >= 0 && minute < 60 && second >= 0 && second < 60)
        {
            // 更新全局时间变量
            currentTime.hour = hour;
            currentTime.minute = minute;
            currentTime.second = second;
            sprintf(text, "TimeUpdated:%02d:%02d:%02d    ", currentTime.hour, currentTime.minute, currentTime.second);
            LCD_DisplayStringLine(Line8, (uint8_t *)text);
        }
        else
        {
            sprintf(text, "    Invalid Time    ");
            LCD_DisplayStringLine(Line8, (uint8_t *)text);
        }
    }
    else
    {
        sprintf(text, "    Invalid Format    ");
        LCD_DisplayStringLine(Line8, (uint8_t *)text);
    }

    // 重新启动 UART 接收，准备接收下一次数据
    HAL_UARTEx_ReceiveToIdle_IT(huart, (uint8_t *)uart_rx, 50);
}
