#ifndef _CLOCK_H_
#define _CLOCK_H_
#include "my_main.h"

struct MyTime {
  uint8_t hour, minute, second;
};

struct Date {
  uint16_t year;
  uint8_t month, day;
};

void clock_init(void);
void clock_run(void);

#endif
