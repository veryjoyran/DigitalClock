#include "clock.h"

struct MyTime currentTime,alarmTime1,alarmTime2,second_chronograph;
struct Date currentDate;




void clock_init(void)
{
	currentDate.year=2024;
	currentDate.day=1;
	currentDate.month=1;
	
	second_chronograph.hour=1;
	second_chronograph.minute=1;
	second_chronograph.second=1;
}

void clock_run(void)
{
    // 更新当前时间
    currentTime.second++;
    if (currentTime.second >= 60)
    {
        currentTime.second = 0;
        currentTime.minute++;
        if (currentTime.minute >= 60)
        {
            currentTime.minute = 0;
            currentTime.hour++;
            if (currentTime.hour >= 24)
            {
                currentTime.hour = 0;
            }
        }       
    }
	
	if (second_chronograph.second > 0) {
            second_chronograph.second--;
        } else if (second_chronograph.minute > 0 || second_chronograph.hour > 0) {
            second_chronograph.second = 59;
            if (second_chronograph.minute > 0) {
                second_chronograph.minute--;
            } else {
                second_chronograph.minute = 59;
                if (second_chronograph.hour > 0) {
                    second_chronograph.hour--;
                }
            }
        }
}


