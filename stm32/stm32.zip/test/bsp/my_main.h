#ifndef _MY_MAIN_
#define _MY_MAIN_

#include "main.h"
#include "gpio.h"
#include "tim.h"
#include "adc.h"
#include "usart.h"

#include "lcd.h"
#include "stdio.h"
#include "key.h"
#include "string.h"
#include "i2c_hal.h"
#include "clock.h"
void setup(void);
void loop(void);
#endif
